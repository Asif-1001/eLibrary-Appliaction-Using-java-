package com.example.elibrary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class SetsActivity2 extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_sets2);

        ImageView imageViewB1 = findViewById(R.id.imageViewB1);
        ImageView imageViewB2 = findViewById(R.id.imageViewB2);
        ImageView imageViewB3 = findViewById(R.id.imageViewB3);
        imageViewB1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intentb1 = new Intent(SetsActivity2.this, ThinkActivity.class);
                startActivity(intentb1);
            }
        });

        imageViewB2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intentb2 = new Intent(SetsActivity2.this, ThinkActivity.class);
                startActivity(intentb2);
            }
        });
        imageViewB3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intentb3 = new Intent(SetsActivity2.this, ThinkActivity.class);
                startActivity(intentb3);
            }
        });
    }
}
