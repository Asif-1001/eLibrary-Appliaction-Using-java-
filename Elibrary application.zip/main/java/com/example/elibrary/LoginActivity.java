package com.example.elibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent; // Added import for Intent
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.WindowManager;


public class LoginActivity extends AppCompatActivity {

    EditText usernameL;
    EditText passwordL;
    Button loginButtonL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameL = findViewById(R.id.usernameL);
        passwordL = findViewById(R.id.passwordL);
        loginButtonL = findViewById(R.id.loginButtonL);  

        loginButtonL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameText = usernameL.getText().toString();
                String passwordText = passwordL.getText().toString();

                if (usernameText.equals("user") && passwordText.equals("pass")) {
                    Intent intent = new Intent(LoginActivity.this, SetsActivity1.class); // Corrected Intent
                    startActivity(intent);
//                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Login Failed Due to Incorrect Id or Password", Toast.LENGTH_SHORT).show();
                }
            }
        });
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

}
