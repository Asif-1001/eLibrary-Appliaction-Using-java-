package com.example.elibrary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class SetsActivity1 extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_sets);

        Button ProceedButton = findViewById(R.id.NextPageButton);
        ImageView A1 = findViewById(R.id.A1);
        ImageView A2 = findViewById(R.id.A2);
        ImageView A3 = findViewById(R.id.A3);
        ProceedButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SetsActivity1.this,SetsActivity2.class);
                startActivity(intent);
            }
        });

        A1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent imagea  = new Intent(SetsActivity1.this,ThinkActivity.class);
                startActivity(imagea);
            }
        });

        A2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent imageb  = new Intent(SetsActivity1.this,ThinkActivity.class);
                startActivity(imageb);
            }
        });
        A3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent imagec  = new Intent(SetsActivity1.this,ThinkActivity.class);
                startActivity(imagec);
            }
        });

    }

}

