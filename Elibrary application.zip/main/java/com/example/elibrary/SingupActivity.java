package com.example.elibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class SingupActivity extends AppCompatActivity {

    EditText namesingup;
    EditText usernamesingup;
    EditText emailsingup;
    EditText numbersingup;
    EditText passwordsingup;
    EditText confirmpasswordsingup;
    Button submitSingup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singup);

        namesingup = findViewById(R.id.namesingup);
        usernamesingup = findViewById(R.id.usernamesingup);
        emailsingup = findViewById(R.id.emailsingup);
        numbersingup = findViewById(R.id.numbersingup);
        passwordsingup = findViewById(R.id.passwordsingup);
        confirmpasswordsingup = findViewById(R.id.confirmpasswordsingup);
        submitSingup = findViewById(R.id.submitSingup);

        submitSingup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nametext = namesingup.getText().toString();
                String usernameText = usernamesingup.getText().toString();
                String emaiaddresstext = emailsingup.getText().toString();
                String phonenumber = numbersingup.getText().toString();
                String passwordText = passwordsingup.getText().toString();
                String confirmpasswort = confirmpasswordsingup.getText().toString();

                // Check if the password and confirm password match
                if (!passwordText.equals(confirmpasswort)) {
                    Toast.makeText(SingupActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Perform registration (you should send this data to your server for storage)
                // For simplicity, let's assume registration is successful
                Toast.makeText(SingupActivity.this, "Registration Successful", Toast.LENGTH_SHORT).show();

                // Redirect to the login page
                Intent intent = new Intent(SingupActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
